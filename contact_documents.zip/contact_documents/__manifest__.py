{
    'name': 'Contacts Documents',
    'version': '16.0.1.0.0',
    'summary': """ Store and access documents for the related contact""",
    'description': """ Store and access documents for the related contact""",
    'author': 'Cybrosys Techno Solutions',
    'company': 'Cybrosys Techno Solutions',
    'website': "https://www.cybrosys.com",
    'maintainer': 'Cybrosys Techno Solutions',
    'depends': ['base', 'contacts', 'website'],
    'data': [
        'views/documents.xml',
    ],

    'license': 'LGPL-3',
    'price': 29,
    'currency': 'EUR',
    'installable': True,
    'auto_install': False,
    'application': False,
}
